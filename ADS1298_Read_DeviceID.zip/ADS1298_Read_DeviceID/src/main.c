#include <zephyr/kernel.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(main, LOG_LEVEL_INF);

#define ADS_CS_PIN 22

static const struct device *spi_dev = DEVICE_DT_GET(DT_NODELABEL(spi1));
static const struct spi_cs_control ads_cs = {
    .gpio = SPI_CS_GPIOS_DT_SPEC_GET(DT_NODELABEL(spi1)),
    .delay = 0,
};

static const struct spi_config spi_cfg = {
    .frequency = 1000000,
    .operation = SPI_WORD_SET(8) | SPI_TRANSFER_MSB | SPI_MODE_CPOL | SPI_MODE_CPHA,
    .slave = 0,
    .cs = ads_cs, // <- Fix is here (was &ads_cs)
};

void main(void)
{
    if (!device_is_ready(spi_dev)) {
        LOG_ERR("SPI device not ready");
        return;
    }

    LOG_INF("SPI ready, starting ADS1298 test");

    uint8_t tx_buf[] = { 0x20, 0x00 }; // Example: RREG command for ID register
    uint8_t rx_buf[2] = {0};

    const struct spi_buf tx_spi_buf = {
        .buf = tx_buf,
        .len = sizeof(tx_buf),
    };

    const struct spi_buf rx_spi_buf = {
        .buf = rx_buf,
        .len = sizeof(rx_buf),
    };

    const struct spi_buf_set tx_set = {
        .buffers = &tx_spi_buf,
        .count = 1,
    };

    const struct spi_buf_set rx_set = {
        .buffers = &rx_spi_buf,
        .count = 1,
    };

    int ret = spi_transceive(spi_dev, &spi_cfg, &tx_set, &rx_set);
    if (ret == 0) {
        LOG_INF("ADS1298 ID: 0x%02X", rx_buf[1]);
    } else {
        LOG_ERR("SPI transfer failed: %d", ret);
    }
}
